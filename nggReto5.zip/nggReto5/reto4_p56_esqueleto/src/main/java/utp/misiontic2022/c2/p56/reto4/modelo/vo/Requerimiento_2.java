package utp.misiontic2022.c2.p56.reto4.modelo.vo;
public class Requerimiento_2 {

    private String proveedor;
    private int ventas;

    public Requerimiento_2(String proveedor, int ventas) {
        this.proveedor = proveedor;
        this.ventas = ventas;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public int getVentas() {
        return ventas;
    }

    public void setVentas(int ventas) {
        this.ventas = ventas;
    }

}
    